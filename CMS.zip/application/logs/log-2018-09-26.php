<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-09-26 10:24:43 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-26 10:24:43 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-26 10:25:28 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-26 10:25:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:29 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-26 10:25:29 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-26 10:25:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:30 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-26 10:25:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:30 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-26 10:25:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:31 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:31 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:31 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:25:32 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-26 10:25:32 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 10:25:32 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 10:25:32 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 10:25:32 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 10:25:32 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 10:25:32 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 10:25:33 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 10:25:33 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 10:25:33 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 10:29:39 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-26 10:29:39 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:39 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:39 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:39 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:39 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:39 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:39 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:29:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:01 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-26 10:30:02 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:02 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:02 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:02 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:02 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:02 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:02 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:02 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:02 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:02 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:03 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:03 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:03 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:03 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:30:03 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 10:31:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\patient\panel.php 52
ERROR - 2018-09-26 10:31:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\patient\panel.php 52
ERROR - 2018-09-26 16:36:26 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-26 16:36:26 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 16:36:26 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:36:26 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 16:36:26 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:36:26 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:36:26 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:36:26 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:36:26 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 16:36:26 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 16:36:30 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:36:30 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:36:30 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 16:36:30 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:36:30 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 16:37:07 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 85
ERROR - 2018-09-26 16:37:08 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 16:37:08 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 16:37:08 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:37:08 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:37:08 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:37:08 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:37:08 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:37:08 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 16:37:08 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 16:38:08 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 85
ERROR - 2018-09-26 16:38:08 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 16:38:08 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 16:38:08 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:38:08 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:38:08 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:38:08 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:38:08 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 16:38:08 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 16:39:57 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 85
ERROR - 2018-09-26 16:39:57 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:39:57 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:39:57 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:39:57 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:45:45 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 50
ERROR - 2018-09-26 16:45:45 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:45:45 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:45:46 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:46:19 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 49
ERROR - 2018-09-26 16:46:19 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:51:23 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-26 16:51:23 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:51:23 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:51:23 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 16:51:23 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 16:51:23 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:51:24 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:51:24 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:51:24 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:51:24 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 16:51:24 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 16:56:22 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-26 16:56:22 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:56:22 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 16:56:22 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:56:22 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 16:56:23 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:56:23 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 16:56:23 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 16:56:23 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 16:56:23 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 16:56:29 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-26 16:56:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 16:56:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 17:01:16 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-26 17:01:17 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 17:01:17 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 17:01:17 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 17:01:17 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 17:01:17 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 17:01:17 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 17:01:17 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 17:01:17 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 17:01:17 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 17:01:17 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 18:35:24 --> Severity: Notice  --> Undefined property: Consume::$drugs C:\wamp\www\clinic\application\controllers\consume.php 30
ERROR - 2018-09-26 18:36:01 --> Severity: Notice  --> Undefined variable: drugs C:\wamp\www\clinic\application\views\consume\list.php 4
ERROR - 2018-09-26 18:37:16 --> Severity: Notice  --> Undefined variable: drugs C:\wamp\www\clinic\application\views\consume\list.php 4
ERROR - 2018-09-26 18:37:17 --> Severity: Notice  --> Undefined variable: drugs C:\wamp\www\clinic\application\views\consume\list.php 4
ERROR - 2018-09-26 18:37:19 --> Severity: Notice  --> Undefined variable: drugs C:\wamp\www\clinic\application\views\consume\list.php 4
ERROR - 2018-09-26 18:37:44 --> Severity: Notice  --> Undefined variable: _drug C:\wamp\www\clinic\application\views\consume\list.php 22
ERROR - 2018-09-26 18:37:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\consume\list.php 22
ERROR - 2018-09-26 18:37:44 --> Severity: Notice  --> Undefined variable: _drug C:\wamp\www\clinic\application\views\consume\list.php 23
ERROR - 2018-09-26 18:37:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\consume\list.php 23
ERROR - 2018-09-26 18:37:44 --> Severity: Notice  --> Undefined variable: _drug C:\wamp\www\clinic\application\views\consume\list.php 24
ERROR - 2018-09-26 18:37:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\consume\list.php 24
ERROR - 2018-09-26 18:37:44 --> Severity: Notice  --> Undefined variable: _drug C:\wamp\www\clinic\application\views\consume\list.php 26
ERROR - 2018-09-26 18:37:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\consume\list.php 26
ERROR - 2018-09-26 18:38:32 --> Severity: Notice  --> Undefined property: Consume::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-26 18:38:32 --> Severity: Notice  --> Undefined property: Consume::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-26 18:38:32 --> Severity: Notice  --> Undefined property: Consume::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-26 18:38:32 --> Severity: Notice  --> Undefined property: Consume::$memo C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-26 18:39:27 --> Severity: Notice  --> Undefined property: Consume::$memo C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-26 18:52:44 --> 404 Page Not Found --> consume/add_consume
ERROR - 2018-09-26 19:21:29 --> Query error: Unknown column 'doctorid' in 'field list'
ERROR - 2018-09-26 19:21:54 --> Query error: Unknown column 'doctorid' in 'field list'
ERROR - 2018-09-26 19:21:55 --> Query error: Unknown column 'doctorid' in 'field list'
ERROR - 2018-09-26 19:21:56 --> Query error: Unknown column 'doctorid' in 'field list'
ERROR - 2018-09-26 19:22:05 --> Query error: Unknown column 'doctorid' in 'field list'
ERROR - 2018-09-26 19:22:23 --> Severity: Notice  --> Undefined property: Consume::$drugs C:\wamp\www\clinic\application\controllers\consume.php 242
ERROR - 2018-09-26 19:22:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\controllers\consume.php 242
ERROR - 2018-09-26 19:35:49 --> 404 Page Not Found --> consume/add_consume
ERROR - 2018-09-26 20:16:16 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-26 20:16:16 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:17 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:17 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:17 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:17 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:17 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:17 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:17 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:17 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:17 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:17 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:17 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:17 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-26 20:16:27 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-26 20:16:27 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 20:16:27 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 20:16:27 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 20:16:27 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 20:16:27 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 20:16:27 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 20:16:27 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-26 20:16:27 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-26 20:16:27 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-26 20:16:28 --> 404 Page Not Found --> account/css
ERROR - 2018-09-26 20:25:51 --> 404 Page Not Found --> consume/new
