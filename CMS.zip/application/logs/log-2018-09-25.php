<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-09-25 16:28:23 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-25 16:30:54 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-25 16:30:56 --> Severity: Notice  --> Undefined variable: id_type_options C:\wamp\www\clinic\application\views\lov\dictionary.php 42
ERROR - 2018-09-25 16:30:56 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-25 16:30:56 --> Severity: Notice  --> Undefined variable: roles_option C:\wamp\www\clinic\application\views\lov\dictionary.php 47
ERROR - 2018-09-25 16:30:56 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-25 16:32:11 --> Severity: Notice  --> Undefined variable: id_type_options C:\wamp\www\clinic\application\views\lov\dictionary.php 42
ERROR - 2018-09-25 16:32:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-25 16:32:11 --> Severity: Notice  --> Undefined variable: roles_option C:\wamp\www\clinic\application\views\lov\dictionary.php 47
ERROR - 2018-09-25 16:32:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-25 16:32:11 --> Severity: Notice  --> Undefined variable: id_type_options C:\wamp\www\clinic\application\views\lov\dictionary.php 42
ERROR - 2018-09-25 16:32:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-25 16:32:11 --> Severity: Notice  --> Undefined variable: roles_option C:\wamp\www\clinic\application\views\lov\dictionary.php 47
ERROR - 2018-09-25 16:32:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-25 16:32:18 --> Severity: Notice  --> Undefined variable: roles_option C:\wamp\www\clinic\application\views\lov\dictionary.php 47
ERROR - 2018-09-25 16:32:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-25 16:32:19 --> Severity: Notice  --> Undefined variable: roles_option C:\wamp\www\clinic\application\views\lov\dictionary.php 47
ERROR - 2018-09-25 16:32:19 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-25 16:37:32 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-25 16:37:32 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:37:32 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-25 16:37:32 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-25 16:37:32 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-25 16:37:32 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:37:32 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:37:32 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:37:32 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:37:32 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:37:32 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:37:33 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:37:33 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:39:48 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-25 16:39:49 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:39:49 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:39:49 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:39:49 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:39:49 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:39:49 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:39:49 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:39:49 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:39:49 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:39:49 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:40:17 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-25 16:40:18 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:40:18 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:40:18 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:40:18 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:40:18 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:40:18 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:40:18 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:40:18 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:40:38 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:40:38 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:40:38 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:40:38 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:40:38 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:42:09 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-25 16:42:09 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:42:09 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:42:09 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:42:09 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:42:09 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:42:09 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:42:09 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:42:10 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:42:10 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:42:10 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:42:12 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-25 16:42:12 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:42:12 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:42:12 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:42:12 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:42:12 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:42:12 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:42:12 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:42:13 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:42:13 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:42:13 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:42:15 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:42:40 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:42:43 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-25 16:42:43 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:42:43 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:42:43 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:42:43 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:42:43 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:42:43 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:42:43 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:42:43 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:42:43 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:42:44 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:42:45 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:43:14 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\lov.php 88
ERROR - 2018-09-25 16:43:14 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:43:14 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:43:14 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:43:14 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:43:14 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:43:14 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:43:14 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:43:14 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:43:16 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\lov.php 88
ERROR - 2018-09-25 16:43:17 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:43:17 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:43:17 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:43:17 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:43:17 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:43:17 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:43:17 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:43:17 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:43:17 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:43:23 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:45:40 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:45:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:40 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:41 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:41 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:41 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:41 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:41 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:41 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:41 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:41 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:43 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:45:43 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:43 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:43 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:43 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:43 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:43 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:43 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:43 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:43 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:43 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:44 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:44 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:44 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:44 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:44 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:44 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:47 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:45:47 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:47 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:47 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:47 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:47 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:47 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:47 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:47 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:47 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:47 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:48 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:48 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:48 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:48 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:48 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:49 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-25 16:45:49 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:45:49 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:45:49 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:45:49 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:45:49 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:45:49 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:45:49 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:45:49 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:45:49 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:45:49 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:45:54 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:45:54 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:54 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:54 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:54 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:54 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:54 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:54 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:54 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:54 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:54 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:45:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:03 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:04 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:05 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-25 16:50:06 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:50:06 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:50:06 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:50:06 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 16:50:06 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 16:50:06 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 16:50:06 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 16:50:12 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:50:12 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:12 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:12 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:12 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:12 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:12 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:12 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:12 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:13 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:13 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:13 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:13 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:13 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:13 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:13 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:13 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:50:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:51:09 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:51:09 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:51:09 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:51:31 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 16:51:31 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-25 16:54:41 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-25 17:04:27 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-25 17:04:27 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 17:04:27 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 17:04:27 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 17:04:27 --> 404 Page Not Found --> account/css
ERROR - 2018-09-25 17:04:28 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 17:04:28 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 17:04:28 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-25 17:04:28 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-25 17:04:28 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-25 17:04:28 --> 404 Page Not Found --> account/css
