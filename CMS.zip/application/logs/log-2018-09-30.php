<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-09-30 10:10:42 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-30 10:11:11 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-30 10:11:25 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-30 10:13:03 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-30 11:31:37 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-30 11:33:52 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-30 14:36:04 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-30 14:36:06 --> Severity: Notice  --> Undefined property: Income::$purchased_drugs C:\wamp\www\clinic\application\controllers\income.php 573
ERROR - 2018-09-30 14:40:01 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:01 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:01 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:01 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:01 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:01 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:03 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:04 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:04 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:04 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:04 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:04 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:04 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:04 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:04 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:04 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:04 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:04 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:04 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:16 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:17 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:17 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:17 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:17 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:17 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:17 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:17 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:17 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:17 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:17 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:17 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:17 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:18 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:18 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:18 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:18 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:18 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:18 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:34 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:34 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:34 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:34 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:34 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:34 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:35 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:40:35 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:40:35 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:40:35 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:35 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:40:35 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:33 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:43:33 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:43:33 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:43:33 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:33 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:33 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:33 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:43:33 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:43:33 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:43:33 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:33 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:33 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:34 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:43:34 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:43:34 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:43:34 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:34 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:34 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:34 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:43:34 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:43:34 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:43:34 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:34 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:34 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:43:35 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:19 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:19 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:19 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:19 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:19 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:19 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:20 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:20 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:20 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:20 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:20 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:20 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:21 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:22 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:23 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:23 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:23 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:23 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:23 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:23 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:32 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 14:52:32 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 14:52:32 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 14:52:32 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:32 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 14:52:32 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:09:12 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:09:12 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:09:12 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:09:12 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:09:12 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:09:12 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:10:58 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:10:58 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:10:58 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:10:58 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:10:58 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:10:58 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:00 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:11:00 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:11:00 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:11:00 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:00 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:00 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:03 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:11:03 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:11:03 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:11:03 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:03 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:03 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:11 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:11:11 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:11:11 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:11:11 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:11 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:11 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:12 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:25 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-30 15:11:26 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:11:26 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:11:26 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:11:26 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:26 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:11:26 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:12:41 --> 404 Page Not Found --> doctor/check
ERROR - 2018-09-30 15:12:47 --> 404 Page Not Found --> doctor/check
ERROR - 2018-09-30 15:13:17 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:13:17 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:13:17 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:13:17 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:13:17 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:13:17 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:14:30 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 591
ERROR - 2018-09-30 15:14:30 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 592
ERROR - 2018-09-30 15:14:30 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 593
ERROR - 2018-09-30 15:14:30 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:14:30 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:14:30 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 594
ERROR - 2018-09-30 15:15:13 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 579
ERROR - 2018-09-30 15:15:13 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 580
ERROR - 2018-09-30 15:15:13 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 581
ERROR - 2018-09-30 15:15:13 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 582
ERROR - 2018-09-30 15:15:13 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 582
ERROR - 2018-09-30 15:15:13 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 582
ERROR - 2018-09-30 15:17:34 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\clinic\application\controllers\income.php 572
ERROR - 2018-09-30 17:16:05 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-30 17:16:05 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:16:05 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:16:05 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:16:05 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:16:05 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:16:05 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:16:05 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-30 17:16:05 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:16:06 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:16:10 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-30 17:16:10 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:10 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:10 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:10 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:10 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:10 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:10 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:10 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:10 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:10 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-30 17:16:10 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:10 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:11 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:11 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:11 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:11 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 17:16:37 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:46:06 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 51
ERROR - 2018-09-30 17:46:06 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:46:06 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:46:06 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:46:06 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:46:06 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:46:06 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:46:06 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:46:06 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:46:06 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:46:07 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:46:20 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 51
ERROR - 2018-09-30 17:46:20 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:46:20 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:46:20 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:46:20 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:46:20 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:46:20 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:46:20 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:46:20 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:46:21 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:47:18 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 46
ERROR - 2018-09-30 17:47:18 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:47:44 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 45
ERROR - 2018-09-30 17:47:44 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:47:50 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 47
ERROR - 2018-09-30 17:47:50 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:48:03 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 51
ERROR - 2018-09-30 17:48:03 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:48:03 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:03 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:03 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:48:03 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:48:03 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:03 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:48:03 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:48:04 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 51
ERROR - 2018-09-30 17:48:04 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:48:05 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:05 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:48:05 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:48:05 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:05 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:48:05 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:05 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:48:05 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:48:09 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 51
ERROR - 2018-09-30 17:48:09 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:48:09 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:48:09 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:09 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:48:09 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:09 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:48:09 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:48:24 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 53
ERROR - 2018-09-30 17:48:24 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:48:24 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:24 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:48:24 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:48:24 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:24 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:48:24 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:24 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:48:25 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:48:30 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-30 17:48:30 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:30 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:48:30 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:30 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:48:30 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:48:30 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:31 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-30 17:48:31 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-30 17:48:31 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-30 17:48:31 --> 404 Page Not Found --> account/css
ERROR - 2018-09-30 17:48:58 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 54
ERROR - 2018-09-30 17:52:56 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 33
ERROR - 2018-09-30 18:18:04 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 33
ERROR - 2018-09-30 18:18:23 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:24 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:25 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-30 18:18:25 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 33
