<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-09-20 08:04:55 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-20 08:04:55 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-20 09:31:23 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-20 10:19:33 --> Severity: Warning  --> file_get_contents(dictionary.txt): failed to open stream: No such file or directory C:\wamp\www\clinic\application\helpers\site_helper.php 29
ERROR - 2018-09-20 10:19:33 --> Severity: Warning  --> file_get_contents(dictionary.txt): failed to open stream: No such file or directory C:\wamp\www\clinic\application\helpers\site_helper.php 29
ERROR - 2018-09-20 10:19:35 --> Severity: Warning  --> file_get_contents(dictionary.txt): failed to open stream: No such file or directory C:\wamp\www\clinic\application\helpers\site_helper.php 29
ERROR - 2018-09-20 10:19:35 --> Severity: Warning  --> file_get_contents(dictionary.txt): failed to open stream: No such file or directory C:\wamp\www\clinic\application\helpers\site_helper.php 29
ERROR - 2018-09-20 11:26:41 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-20 11:35:43 --> 404 Page Not Found --> dictionary
ERROR - 2018-09-20 11:37:42 --> 404 Page Not Found --> lov
ERROR - 2018-09-20 11:38:35 --> 404 Page Not Found --> account/dictionary
ERROR - 2018-09-20 11:39:15 --> 404 Page Not Found --> account/dictionary
ERROR - 2018-09-20 11:40:12 --> 404 Page Not Found --> lov
ERROR - 2018-09-20 11:42:26 --> 404 Page Not Found --> lov
ERROR - 2018-09-20 11:55:35 --> 404 Page Not Found --> lov
ERROR - 2018-09-20 11:55:46 --> 404 Page Not Found --> application
ERROR - 2018-09-20 11:56:09 --> 404 Page Not Found --> application
ERROR - 2018-09-20 11:56:14 --> 404 Page Not Found --> application
ERROR - 2018-09-20 11:56:18 --> 404 Page Not Found --> lov
ERROR - 2018-09-20 11:57:25 --> 404 Page Not Found --> lov
ERROR - 2018-09-20 11:58:41 --> 404 Page Not Found --> lov
ERROR - 2018-09-20 11:59:27 --> 404 Page Not Found --> lov
ERROR - 2018-09-20 12:05:42 --> 404 Page Not Found --> lov
ERROR - 2018-09-20 12:06:55 --> 404 Page Not Found --> lov
ERROR - 2018-09-20 12:21:52 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-20 12:26:17 --> 404 Page Not Found --> lov
ERROR - 2018-09-20 12:58:07 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6676 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 12:58:26 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6676 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 12:58:32 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6676 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 12:59:26 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6676 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 12:59:27 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6676 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:00:26 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6676 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:00:27 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6676 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:00:58 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6676 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:01:08 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6676 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:09:23 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6680 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:09:27 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6680 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:09:32 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6680 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:10:21 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6671 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:10:23 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6671 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:10:37 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6669 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:10:38 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6669 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:10:56 --> Severity: Notice  --> unserialize(): Error at offset 6488 of 6668 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:10:57 --> Severity: Notice  --> unserialize(): Error at offset 6488 of 6668 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:11:08 --> Severity: Notice  --> unserialize(): Error at offset 6488 of 6668 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:11:09 --> Severity: Notice  --> unserialize(): Error at offset 6488 of 6668 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 13:19:22 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 13:19:22 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 13:19:22 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-20 13:19:22 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-20 13:19:22 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 13:19:27 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 13:19:28 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:19:28 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:19:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:19:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:19:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:19:30 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:19:31 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:19:31 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:19:31 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:19:31 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:19:51 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-20 13:19:51 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 13:19:52 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 13:19:52 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-20 13:19:52 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 13:20:58 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-20 13:20:58 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 13:20:58 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 13:20:58 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-20 13:20:58 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 13:32:53 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 13:32:53 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 13:32:53 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-20 13:32:53 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-20 13:32:54 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 13:33:14 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 13:33:14 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:33:14 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:33:14 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:33:14 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:33:14 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:33:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:33:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:33:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:33:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:33:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:33:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:40:55 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 13:40:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:40:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:40:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:40:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:40:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:40:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:40:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:40:55 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:40:56 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:40:56 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:40:56 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:43:04 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 13:43:04 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 13:43:04 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-20 13:43:04 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 13:43:04 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-20 13:43:08 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 13:43:08 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:43:08 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:43:08 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:43:08 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:43:08 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:43:08 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:43:08 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:43:08 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:43:08 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 13:43:09 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 14:39:30 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6669 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 14:39:58 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6669 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 14:40:08 --> Severity: Notice  --> unserialize(): Error at offset 6586 of 6669 bytes C:\wamp\www\clinic\application\helpers\site_helper.php 30
ERROR - 2018-09-20 16:09:14 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:09:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:09:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:09:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:09:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:09:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:09:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:09:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:09:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:09:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:09:15 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:09:16 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:14:49 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:14:49 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:14:50 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:14:50 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:14:50 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:14:50 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:14:50 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:14:50 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:14:50 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:14:50 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:14:50 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:14:50 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-20 16:17:11 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:17:12 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:17:55 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:17:56 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:17:56 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:18:46 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:18:46 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:18:47 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:18:49 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:19:22 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:19:23 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:30:36 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:30:37 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:40:51 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:40:56 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 16:43:15 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 16:43:15 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-20 16:43:15 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 16:43:15 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 16:43:15 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-20 16:55:45 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 16:55:45 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-20 16:55:45 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 16:55:45 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 16:55:45 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-20 16:56:16 --> Severity: Notice  --> Undefined index: test C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-20 16:56:16 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-20 16:56:16 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 16:56:16 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 16:56:16 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-20 16:56:16 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 16:56:36 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-20 16:56:37 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 16:56:37 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 16:56:37 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-20 16:56:37 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-20 16:56:37 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 16:59:04 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-20 16:59:04 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-20 16:59:04 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 16:59:04 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-20 16:59:04 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 16:59:04 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 16:59:05 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-20 16:59:05 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-20 16:59:05 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 16:59:05 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-20 16:59:06 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 16:59:06 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 17:01:10 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-20 17:01:10 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 17:01:10 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-20 17:01:10 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-20 17:01:10 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-20 17:01:11 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 17:01:21 --> 404 Page Not Found --> account/css
ERROR - 2018-09-20 17:01:29 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-20 17:54:49 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
