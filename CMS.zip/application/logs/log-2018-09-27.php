<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-09-27 21:50:07 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-27 21:50:09 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-27 22:17:57 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-27 22:17:57 --> Severity: Warning  --> include_once(sidebar/incmoe.php): failed to open stream: No such file or directory C:\wamp\www\clinic\application\views\repository\sidebar.php 43
ERROR - 2018-09-27 22:17:57 --> Severity: Warning  --> include_once(): Failed opening 'sidebar/incmoe.php' for inclusion (include_path='.;C:\php\pear') C:\wamp\www\clinic\application\views\repository\sidebar.php 43
ERROR - 2018-09-27 22:19:30 --> Severity: Warning  --> include_once(sidebar/incmoe.php): failed to open stream: No such file or directory C:\wamp\www\clinic\application\views\repository\sidebar.php 43
ERROR - 2018-09-27 22:19:30 --> Severity: Warning  --> include_once(): Failed opening 'sidebar/incmoe.php' for inclusion (include_path='.;C:\php\pear') C:\wamp\www\clinic\application\views\repository\sidebar.php 43
ERROR - 2018-09-27 22:20:46 --> 404 Page Not Found --> consume/new_incmoe
ERROR - 2018-09-27 22:21:52 --> 404 Page Not Found --> incmoe
ERROR - 2018-09-27 22:24:51 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-27 22:24:53 --> 404 Page Not Found --> incmoe
ERROR - 2018-09-27 22:26:07 --> 404 Page Not Found --> incmoe
ERROR - 2018-09-27 22:27:19 --> 404 Page Not Found --> income/new_income
ERROR - 2018-09-27 22:31:43 --> Severity: Notice  --> Undefined property: Income::$consumes C:\wamp\www\clinic\application\controllers\income.php 30
ERROR - 2018-09-27 22:34:06 --> Severity: Notice  --> Undefined variable: consumes C:\wamp\www\clinic\application\views\income\list.php 4
ERROR - 2018-09-27 22:34:31 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-27 22:34:31 --> Severity: Notice  --> Undefined property: Income::$count C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-27 22:34:31 --> Severity: Notice  --> Undefined property: Income::$price C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-27 22:35:21 --> 404 Page Not Found --> income/new_income
ERROR - 2018-09-27 22:37:24 --> 404 Page Not Found --> income/new_income
ERROR - 2018-09-27 22:40:13 --> 404 Page Not Found --> income/new_income
ERROR - 2018-09-27 22:40:20 --> 404 Page Not Found --> income/new_income
ERROR - 2018-09-27 22:44:15 --> Severity: Notice  --> Undefined variable: income C:\wamp\www\clinic\application\controllers\income.php 239
ERROR - 2018-09-27 22:44:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\application\controllers\income.php 239
ERROR - 2018-09-27 22:44:15 --> Query error: Column 'type' cannot be null
