<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-09-24 16:08:52 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-24 16:09:50 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-24 16:09:50 --> 404 Page Not Found --> account/css
ERROR - 2018-09-24 16:09:50 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-24 16:09:50 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-24 16:09:50 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-24 16:09:50 --> 404 Page Not Found --> account/themes
