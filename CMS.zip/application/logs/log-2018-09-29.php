<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-09-29 07:23:42 --> Severity: Notice  --> Undefined property: Consume::$drugs C:\wamp\www\clinic\application\controllers\consume.php 97
ERROR - 2018-09-29 07:23:49 --> Severity: Notice  --> Undefined property: Consume::$drugs C:\wamp\www\clinic\application\controllers\consume.php 97
ERROR - 2018-09-29 07:24:00 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-29 07:28:28 --> Severity: Notice  --> Undefined property: Consume::$drugs C:\wamp\www\clinic\application\controllers\consume.php 97
ERROR - 2018-09-29 07:29:12 --> 404 Page Not Found --> incmoe
ERROR - 2018-09-29 07:29:14 --> 404 Page Not Found --> incmoe
ERROR - 2018-09-29 07:29:17 --> 404 Page Not Found --> incmoe
ERROR - 2018-09-29 07:35:05 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-29 07:35:08 --> 404 Page Not Found --> incmoe
ERROR - 2018-09-29 07:35:48 --> Severity: Notice  --> Undefined variable: drug_id C:\wamp\www\clinic\application\controllers\income.php 131
ERROR - 2018-09-29 07:35:48 --> Severity: Notice  --> Undefined property: Income::$drugs C:\wamp\www\clinic\application\controllers\income.php 133
ERROR - 2018-09-29 07:36:24 --> Severity: Notice  --> Undefined variable: drug_id C:\wamp\www\clinic\application\controllers\income.php 131
ERROR - 2018-09-29 07:36:24 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:36:52 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:37:03 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:39:07 --> Severity: Notice  --> Undefined variable: drug_id C:\wamp\www\clinic\application\controllers\income.php 112
ERROR - 2018-09-29 07:39:51 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:40:19 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:41:26 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:42:57 --> Severity: Notice  --> Undefined variable: drug_id C:\wamp\www\clinic\application\controllers\income.php 162
ERROR - 2018-09-29 07:42:57 --> Severity: Notice  --> Undefined variable: drug_id C:\wamp\www\clinic\application\controllers\income.php 198
ERROR - 2018-09-29 07:43:28 --> Severity: Notice  --> Undefined property: Income::$drugs C:\wamp\www\clinic\application\controllers\income.php 162
ERROR - 2018-09-29 07:44:51 --> Severity: Notice  --> Undefined property: Income::$drugs C:\wamp\www\clinic\application\controllers\income.php 162
ERROR - 2018-09-29 07:44:52 --> Severity: Notice  --> Undefined property: Income::$drugs C:\wamp\www\clinic\application\controllers\income.php 162
ERROR - 2018-09-29 07:44:55 --> Severity: Notice  --> Undefined property: Income::$drugs C:\wamp\www\clinic\application\controllers\income.php 162
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\income\confirm_delete.php 2
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\confirm_delete.php 2
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\income\confirm_delete.php 7
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\confirm_delete.php 7
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\income\confirm_delete.php 10
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\confirm_delete.php 10
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\income\confirm_delete.php 13
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\confirm_delete.php 13
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\income\confirm_delete.php 14
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\confirm_delete.php 14
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\income\confirm_delete.php 25
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\confirm_delete.php 25
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\income\confirm_delete.php 26
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\confirm_delete.php 26
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\income\confirm_delete.php 30
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\confirm_delete.php 30
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\income\confirm_delete.php 39
ERROR - 2018-09-29 07:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\confirm_delete.php 39
ERROR - 2018-09-29 07:46:36 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:46:36 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:46:36 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:46:36 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:46:36 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:46:36 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:46:36 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:47:07 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:47:07 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:47:07 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:47:07 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:47:07 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:47:52 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:47:52 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:47:52 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:47:52 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:47:52 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:48:16 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:48:16 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:48:16 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:48:43 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:48:43 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:48:43 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:48:43 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:48:43 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:48:43 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:51 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:51 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:52 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:52 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:53 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:53 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:54 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:54 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:54 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:54 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:54 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:54 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:55 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:55 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:55 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:55 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:55 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:55 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:55 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:55 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:55 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:55 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:56 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:56 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:56 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:56 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:56 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:56 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:56 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:56 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:56 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:56 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:57 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:57 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:57 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:57 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:57 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:57 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:57 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:57 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:57 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:57 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:58 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:49:58 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:04 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 572
ERROR - 2018-09-29 07:50:04 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 573
ERROR - 2018-09-29 07:50:04 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 574
ERROR - 2018-09-29 07:50:04 --> Severity: Notice  --> Undefined variable: sold_drugs_count C:\wamp\www\clinic\application\controllers\income.php 575
ERROR - 2018-09-29 07:50:04 --> Severity: Notice  --> Undefined variable: returned_drugs_count C:\wamp\www\clinic\application\controllers\income.php 575
ERROR - 2018-09-29 07:50:04 --> Severity: Notice  --> Undefined variable: all_drugs_count C:\wamp\www\clinic\application\controllers\income.php 575
ERROR - 2018-09-29 07:50:06 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:06 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:06 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:16 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:16 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:16 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:18 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:18 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:18 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:18 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:18 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:18 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:18 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:18 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:18 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:19 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:19 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:19 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:22 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:22 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:22 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:23 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:23 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:23 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:24 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:24 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:24 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:25 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:26 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:26 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:26 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:26 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:26 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:50:26 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:51:17 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:51:17 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 07:51:17 --> Severity: Notice  --> Undefined property: Income::$drug_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 08:02:12 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 08:09:58 --> Severity: Notice  --> Undefined property: Income::$income_id C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 08:14:24 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 08:14:47 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 08:15:00 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 08:42:50 --> Severity: Notice  --> Undefined property: Consume::$drugs C:\wamp\www\clinic\application\controllers\consume.php 97
ERROR - 2018-09-29 08:46:51 --> Severity: Notice  --> Undefined property: Consume::$drugs C:\wamp\www\clinic\application\controllers\consume.php 97
ERROR - 2018-09-29 10:59:29 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-29 11:05:15 --> Severity: Notice  --> Undefined variable: id_type_options C:\wamp\www\clinic\application\views\income\new.php 18
ERROR - 2018-09-29 11:05:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-29 11:18:17 --> Severity: Notice  --> Undefined variable: doctors C:\wamp\www\clinic\application\controllers\income.php 631
ERROR - 2018-09-29 11:18:17 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\application\controllers\income.php 631
ERROR - 2018-09-29 11:18:17 --> Severity: Notice  --> Undefined variable: doctor_list C:\wamp\www\clinic\application\controllers\income.php 635
ERROR - 2018-09-29 11:18:17 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-29 11:18:53 --> Severity: Notice  --> Undefined variable: doctors C:\wamp\www\clinic\application\controllers\income.php 631
ERROR - 2018-09-29 11:18:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\application\controllers\income.php 631
ERROR - 2018-09-29 11:18:53 --> Severity: Notice  --> Undefined variable: doctor_list C:\wamp\www\clinic\application\controllers\income.php 635
ERROR - 2018-09-29 11:18:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-29 12:23:50 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:50 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:50 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:50 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:50 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:50 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:50 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:50 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:50 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:55 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:55 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:55 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:55 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:55 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:55 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:55 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:55 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:23:55 --> Severity: Notice  --> Undefined property: Income::$ds C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:57:31 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:31 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:31 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:31 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:31 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:31 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:31 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:31 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:31 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:57:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 28
ERROR - 2018-09-29 12:58:11 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:11 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:11 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:11 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:11 --> Severity: Notice  --> Undefined offset: 88 C:\wamp\www\clinic\application\views\income\list.php 29
ERROR - 2018-09-29 12:58:11 --> Severity: Notice  --> Undefined offset: 44 C:\wamp\www\clinic\application\views\income\list.php 29
ERROR - 2018-09-29 12:58:11 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:11 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:11 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:12 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:12 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:12 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:12 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:12 --> Severity: Notice  --> Undefined offset: 88 C:\wamp\www\clinic\application\views\income\list.php 29
ERROR - 2018-09-29 12:58:12 --> Severity: Notice  --> Undefined offset: 44 C:\wamp\www\clinic\application\views\income\list.php 29
ERROR - 2018-09-29 12:58:12 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:12 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:12 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:58:36 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:58:36 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:58:36 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:58:36 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:58:36 --> Severity: Notice  --> Undefined offset: 88 C:\wamp\www\clinic\application\views\income\list.php 29
ERROR - 2018-09-29 12:58:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 29
ERROR - 2018-09-29 12:58:36 --> Severity: Notice  --> Undefined offset: 44 C:\wamp\www\clinic\application\views\income\list.php 29
ERROR - 2018-09-29 12:58:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 29
ERROR - 2018-09-29 12:58:36 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:58:36 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:58:36 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 12:59:34 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:59:34 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:59:34 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:59:34 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:59:34 --> Severity: Notice  --> Undefined offset: 88 C:\wamp\www\clinic\application\views\income\list.php 29
ERROR - 2018-09-29 12:59:34 --> Severity: Notice  --> Undefined offset: 44 C:\wamp\www\clinic\application\views\income\list.php 29
ERROR - 2018-09-29 12:59:34 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:59:34 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 12:59:34 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:00:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 30
ERROR - 2018-09-29 13:01:02 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 13:01:02 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 13:01:02 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 13:01:02 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 13:01:02 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 13:01:02 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 13:01:02 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 13:01:02 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 13:01:02 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 13:01:18 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:18 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:18 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:18 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:18 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:18 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:18 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:18 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:18 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:19 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:19 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:19 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:19 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:19 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:19 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:19 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:19 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:01:19 --> Severity: Warning  --> htmlspecialchars() expects parameter 1 to be string, object given C:\wamp\www\clinic\system\core\Common.php 558
ERROR - 2018-09-29 13:03:14 --> Severity: Notice  --> Undefined offset: 4 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:14 --> Severity: Notice  --> Undefined offset: 5 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:14 --> Severity: Notice  --> Undefined offset: 88 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:14 --> Severity: Notice  --> Undefined offset: 44 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:15 --> Severity: Notice  --> Undefined offset: 4 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:15 --> Severity: Notice  --> Undefined offset: 5 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:15 --> Severity: Notice  --> Undefined offset: 88 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:15 --> Severity: Notice  --> Undefined offset: 44 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\income\list.php 31
ERROR - 2018-09-29 13:12:57 --> Severity: Notice  --> Undefined variable: doctor_name C:\wamp\www\clinic\application\views\income\list.php 38
ERROR - 2018-09-29 13:12:57 --> Severity: Notice  --> Undefined variable: doctor_name C:\wamp\www\clinic\application\views\income\list.php 38
ERROR - 2018-09-29 13:12:57 --> Severity: Notice  --> Use of undefined constant doctor_id - assumed 'doctor_id' C:\wamp\www\clinic\application\views\income\list.php 23
ERROR - 2018-09-29 13:13:16 --> Severity: Notice  --> Use of undefined constant doctor_id - assumed 'doctor_id' C:\wamp\www\clinic\application\views\income\list.php 24
ERROR - 2018-09-29 13:14:15 --> Severity: Notice  --> Use of undefined constant id - assumed 'id' C:\wamp\www\clinic\application\views\income\list.php 24
ERROR - 2018-09-29 13:14:16 --> Severity: Notice  --> Use of undefined constant id - assumed 'id' C:\wamp\www\clinic\application\views\income\list.php 24
ERROR - 2018-09-29 17:33:43 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-29 17:38:00 --> Severity: Notice  --> Undefined variable: type_options C:\wamp\www\clinic\application\views\income\edit.php 10
ERROR - 2018-09-29 17:38:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-29 17:38:31 --> Severity: Notice  --> Undefined variable: doctor_list C:\wamp\www\clinic\application\views\income\edit.php 10
ERROR - 2018-09-29 17:38:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\clinic\system\helpers\form_helper.php 331
ERROR - 2018-09-29 18:03:09 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\clinic\application\views\income\edit.php 12
ERROR - 2018-09-29 18:03:24 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\clinic\application\views\income\edit.php 12
ERROR - 2018-09-29 18:04:20 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 18:04:20 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\clinic\application\views\income\edit.php 12
ERROR - 2018-09-29 18:04:35 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\clinic\application\views\income\edit.php 12
ERROR - 2018-09-29 18:05:12 --> Severity: Notice  --> Undefined property: Income::$name C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-29 18:05:12 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\clinic\application\views\income\edit.php 12
ERROR - 2018-09-29 18:05:23 --> Severity: 4096  --> Object of class Incomes could not be converted to string C:\wamp\www\clinic\application\controllers\income.php 140
ERROR - 2018-09-29 18:05:23 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\clinic\application\views\income\edit.php 12
ERROR - 2018-09-29 18:16:42 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\clinic\application\views\income\edit.php 12
ERROR - 2018-09-29 18:44:28 --> Severity: Warning  --> mysql_fetch_object(): supplied argument is not a valid MySQL result resource C:\wamp\www\clinic\application\helpers\site_helper.php 53
ERROR - 2018-09-29 18:44:28 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-29 18:44:28 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-29 18:44:28 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-29 18:44:28 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-29 18:44:28 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-29 18:44:28 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-29 18:44:28 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-29 18:44:28 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-29 18:44:28 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-29 18:44:28 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-29 18:44:28 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-29 18:44:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-29 18:44:29 --> 404 Page Not Found --> account/assets
ERROR - 2018-09-29 18:44:29 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-29 18:44:29 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-29 18:44:29 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-29 18:44:29 --> 404 Page Not Found --> account/css
ERROR - 2018-09-29 18:44:29 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-29 18:44:29 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-29 18:44:29 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-29 18:44:29 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-29 18:44:30 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-29 18:44:30 --> 404 Page Not Found --> account/css
ERROR - 2018-09-29 18:44:32 --> Severity: Notice  --> Undefined index: clinicname C:\wamp\www\clinic\application\views\lov\dictionary.php 88
ERROR - 2018-09-29 18:44:32 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-29 18:44:32 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-29 18:44:32 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-29 18:44:32 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-29 18:44:32 --> 404 Page Not Found --> account/css
ERROR - 2018-09-29 18:44:32 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-29 18:44:32 --> 404 Page Not Found --> account/easyui-rtl.css
ERROR - 2018-09-29 18:44:32 --> 404 Page Not Found --> account/themes
ERROR - 2018-09-29 18:44:32 --> 404 Page Not Found --> account/demo.css
ERROR - 2018-09-29 18:44:33 --> 404 Page Not Found --> account/css
