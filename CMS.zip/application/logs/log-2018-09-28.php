<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-09-28 12:16:33 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-28 12:16:33 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-28 12:26:20 --> 404 Page Not Found --> doctor/index
ERROR - 2018-09-28 12:28:14 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-28 16:31:27 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 4
ERROR - 2018-09-28 16:31:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 4
ERROR - 2018-09-28 16:31:27 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 10
ERROR - 2018-09-28 16:31:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 10
ERROR - 2018-09-28 16:31:27 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 11
ERROR - 2018-09-28 16:31:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 11
ERROR - 2018-09-28 16:31:27 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 14
ERROR - 2018-09-28 16:31:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 14
ERROR - 2018-09-28 16:31:27 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 15
ERROR - 2018-09-28 16:31:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 15
ERROR - 2018-09-28 16:31:27 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 23
ERROR - 2018-09-28 16:31:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 23
ERROR - 2018-09-28 16:35:08 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-28 16:35:08 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 10
ERROR - 2018-09-28 16:35:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 10
ERROR - 2018-09-28 16:35:08 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 11
ERROR - 2018-09-28 16:35:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 11
ERROR - 2018-09-28 16:35:08 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 14
ERROR - 2018-09-28 16:35:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 14
ERROR - 2018-09-28 16:35:08 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 15
ERROR - 2018-09-28 16:35:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 15
ERROR - 2018-09-28 16:35:08 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 23
ERROR - 2018-09-28 16:35:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 23
ERROR - 2018-09-28 16:35:25 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 10
ERROR - 2018-09-28 16:35:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 10
ERROR - 2018-09-28 16:35:25 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 11
ERROR - 2018-09-28 16:35:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 11
ERROR - 2018-09-28 16:35:25 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 14
ERROR - 2018-09-28 16:35:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 14
ERROR - 2018-09-28 16:35:25 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 15
ERROR - 2018-09-28 16:35:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 15
ERROR - 2018-09-28 16:35:27 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 10
ERROR - 2018-09-28 16:35:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 10
ERROR - 2018-09-28 16:35:27 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 11
ERROR - 2018-09-28 16:35:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 11
ERROR - 2018-09-28 16:35:27 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 14
ERROR - 2018-09-28 16:35:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 14
ERROR - 2018-09-28 16:35:27 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 15
ERROR - 2018-09-28 16:35:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 15
ERROR - 2018-09-28 16:36:13 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 10
ERROR - 2018-09-28 16:36:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 10
ERROR - 2018-09-28 16:36:13 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 11
ERROR - 2018-09-28 16:36:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 11
ERROR - 2018-09-28 16:36:13 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 14
ERROR - 2018-09-28 16:36:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 14
ERROR - 2018-09-28 16:36:13 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 15
ERROR - 2018-09-28 16:36:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 15
ERROR - 2018-09-28 16:36:14 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 10
ERROR - 2018-09-28 16:36:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 10
ERROR - 2018-09-28 16:36:14 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 11
ERROR - 2018-09-28 16:36:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 11
ERROR - 2018-09-28 16:36:14 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 14
ERROR - 2018-09-28 16:36:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 14
ERROR - 2018-09-28 16:36:14 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\edit.php 15
ERROR - 2018-09-28 16:36:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\edit.php 15
ERROR - 2018-09-28 17:01:19 --> Severity: Notice  --> Undefined property: Doctor::$drugs C:\wamp\www\clinic\application\controllers\doctor.php 163
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 7
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 7
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 10
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 10
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 13
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 13
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 14
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 14
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 25
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 25
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 26
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 26
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 30
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 30
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 39
ERROR - 2018-09-28 17:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 39
ERROR - 2018-09-28 17:09:41 --> Severity: Notice  --> Undefined variable: doctor_id C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 17:10:23 --> Severity: Notice  --> Undefined variable: doctor_id C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 17:10:53 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 17:14:10 --> Severity: Notice  --> Array to string conversion C:\wamp\www\clinic\application\controllers\doctor.php 204
ERROR - 2018-09-28 17:15:02 --> Severity: Notice  --> Array to string conversion C:\wamp\www\clinic\application\controllers\doctor.php 205
ERROR - 2018-09-28 17:16:38 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 17:19:12 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 17:23:08 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 17:23:09 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 7
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 7
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 10
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 10
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 13
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 13
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 14
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 14
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 25
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 25
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 26
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 26
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 30
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 30
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 39
ERROR - 2018-09-28 17:46:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 39
ERROR - 2018-09-28 17:48:20 --> Severity: Notice  --> Undefined property: Doctor::$drug_name_en C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-28 17:48:20 --> Severity: Notice  --> Undefined property: Doctor::$drug_name_en C:\wamp\www\clinic\system\core\Model.php 51
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 2
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 7
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 7
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 10
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 10
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 13
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 13
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 14
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 14
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 25
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 25
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 26
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 26
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 30
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 30
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 39
ERROR - 2018-09-28 18:24:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 39
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 7
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 7
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 10
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 10
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 13
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 13
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 14
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 14
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 25
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 25
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 26
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 26
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 30
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 30
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 39
ERROR - 2018-09-28 18:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 39
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 10
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 10
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 13
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 13
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 14
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 14
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 25
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 25
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 26
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 26
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 30
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 30
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 39
ERROR - 2018-09-28 18:25:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 39
ERROR - 2018-09-28 18:25:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 13
ERROR - 2018-09-28 18:25:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 13
ERROR - 2018-09-28 18:25:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 14
ERROR - 2018-09-28 18:25:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 14
ERROR - 2018-09-28 18:25:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 25
ERROR - 2018-09-28 18:25:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 25
ERROR - 2018-09-28 18:25:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 26
ERROR - 2018-09-28 18:25:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 26
ERROR - 2018-09-28 18:25:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 30
ERROR - 2018-09-28 18:25:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 30
ERROR - 2018-09-28 18:25:32 --> Severity: Notice  --> Undefined variable: drug C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 39
ERROR - 2018-09-28 18:25:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\clinic\application\views\doctor\confirm_delete.php 39
ERROR - 2018-09-28 19:09:40 --> 404 Page Not Found --> doctor/delete
ERROR - 2018-09-28 19:09:41 --> 404 Page Not Found --> doctor/delete
ERROR - 2018-09-28 19:09:41 --> 404 Page Not Found --> doctor/delete
ERROR - 2018-09-28 19:09:41 --> 404 Page Not Found --> doctor/delete
ERROR - 2018-09-28 19:09:42 --> 404 Page Not Found --> doctor/delete
ERROR - 2018-09-28 19:09:42 --> 404 Page Not Found --> doctor/delete
