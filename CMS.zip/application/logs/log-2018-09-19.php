<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-09-19 17:47:17 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'c2203958rw'@'localhost' (using password: YES) C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-19 17:47:17 --> Unable to connect to the database
ERROR - 2018-09-19 17:59:11 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'c2203958rw'@'localhost' (using password: YES) C:\wamp\www\clinic\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2018-09-19 17:59:11 --> Unable to connect to the database
