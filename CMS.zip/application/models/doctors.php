<?php

class Doctors extends MY_Model {
    
    const DB_TABLE = 'doctors';
    const DB_TABLE_PK = 'id';
    
    /**
     * Table unique identifier.
     * @var int
     */
    public $id;
    
    /**
     * Item Name in English.
     * @var string
     */
    public $name;
    
    /**
     * Count
     * @var int
     */
    public $address;
    
    /*
     * Doctor id
     * @var int
     */
    public $phone;
    
    /*
     * Date of 
     * @var Date
     */
    public $created_date;
        
}