<?php

class Incomes extends MY_Model {
    
    const DB_TABLE = 'incomes';
    const DB_TABLE_PK = 'id';
    
    /**
     * Table unique identifier.
     * @var int
     */
    public $id;
    
    /**
     * Item Name in English.
     * @var string
     */
    public $type;
    
    /**
     * Count
     * @var int
     */
    public $amount;
    
    /*
     * Doctor id
     * @var int
     */
    public $doctor_id;
    
    /*
     * Date of 
     * @var Date
     */
    public $date;
        
}