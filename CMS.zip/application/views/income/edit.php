<div class="row">
<?php if(!empty($income->id)){ ?>
  <div class="col col-md-8 well well-sm">
    <?php echo form_open('income/edit/'.$income->id,array("id"=>"newIncomeForm", "role"=>"form",)); ?>
      <fieldset>
        <legend>- Income Information:</legend>
        <div>
          <?php echo ( !empty($error) ? $error : '' ); ?>
          <div class="form-group">
              <div class="col-md-12"><?php echo form_dropdown('doctor_id',$doctor_list,
                $income->doctor_id,"class='form-control' title='Doctor' required");?></div>
              
            <div class="col-md-6"><input type="number" name='amount' id='amount' value="<?php echo set_value('amount', $income->amount);?>" class='form-control' placeholder='amount' title='amount' required /></div>
          </div>
          <div class="form-group">            
            <div class="col-md-6"><?php echo form_dropdown('type',$type_options,$income->type,"class='form-control' title='Type'");?></div>
          </div>
          <div class="clearfix"></div>
      </fieldset>      
      <div class="form-group">
        <div class="col-md-6"><input type="submit" name='submit' id='submit' value='Update' class="form-control btn btn-info" /></div>
        <div class="col-md-6"><?php echo anchor('income','Cancel',array('class'=>'form-control btn btn-info'));?></div>
      </div>
    <?php echo form_close(); ?>
  </div>
<?php
}else{
  echo '<div class="alert alert-danger text-center"><h1>Income Not Found</h1></div><div class="pull-right" title="Go to Incomes">'.anchor('income', '<span class="glyphicon glyphicon-arrow-left"></span>').'</div>';
}
?>
</div>
<script>
  $(document).ready(function(){

  });
</script>