<legend><?php echo "- ".@$title;?></legend>
<?php //pagination should be added if have time.

if($incomes)
{
  echo "<div>".$pagination."<div class='table-responsive'><table id='income_list_table' class='table table-bordered table-striped'><thead><tr>
           <th>ID</th>           
           <th>اسم الدكتور</th>
           <th>المبلغ </th>           
           <th>النمط</th>           
           <th>التاريخ</th>           
           <th></th>
       </tr></thead><tbody>";
  $start = ($page-1) * $per_page;
  $i=0;
  foreach($incomes as $_income)
  {
    if($i>=(int)$start&&$i<(int)$start+(int)$per_page)
    {
        $doctor_name = '';
        foreach($doctors as $_doctor){
            if ($_doctor->id == $_income->doctor_id)
                $doctor_name = $_doctor->name;
        }
        $actions = '';
        if($this->bitauth->has_role('pharmacy'))
        {
          $actions .= anchor('income/edit/'.$_income->id, '<span class="glyphicon glyphicon-edit"></span>',array('title'=>'Edit Drug'));
          $actions .= anchor('income/delete/'.$_income->id, '<span class="glyphicon glyphicon-remove"></span>',array('title'=>'Delete Drug'));
          $actions .= anchor('income/check/'.$_income->id, '<span class="glyphicon glyphicon-check"></span>',array('title'=>'Check Availability'));
        }
        echo '<tr id="income'.$_income->id.'">'.
          '<td>'.html_escape($_income->id).'</td>'.
          '<td>'.html_escape($doctor_name).'</td>'.                      
          '<td>'.html_escape($_income->amount).'</td>'.                              
          '<td>'.html_escape($_income->type).'</td>'.                      
          '<td>'.html_escape($_income->date).'</td>'.                              
          '<td class="hidden-print">'.$actions.'</td>'.
        '</tr>';
    }
    $i++;
  }
  echo '</tbody></table></div>'.$pagination."</div>";
  ?>
<script>
    $(document).ready(function(){ 
        $('#income_list_table a').on('click',function(e){
            if($(this).attr('title')=='Delete Drug'){
               e.preventDefault();
               $.get($(this).attr('href'),'',function(data){
                   $('#tmpDiv').html(data);
               });
            }
        });
        $('#income_list_table a').on('click',function(e){
            if($(this).attr('title')=='Check Availability'){
               e.preventDefault();
               $.get($(this).attr('href'),'',function(data){
                   $('#tmpDiv').html(data);
               });
            }
        });
    });
</script>
<?php
}
echo '<div class="hidden-print">'.anchor('income/new_income', 'Register new Income',array('class'=>'hidden-print')).'</div>';
?>