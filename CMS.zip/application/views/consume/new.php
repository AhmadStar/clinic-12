<div class="row">
  <div class="col col-md-8 well well-sm">
    <?php echo form_open('consume/new_consume',array("id"=>"newConsumeForm", "role"=>"form",)); ?>
      <fieldset>
        <legend>- Consume Information:</legend>
        <div>
          <?php echo ( !empty($error) ? $error : '' ); ?>
          <div class="form-group">
            <div class="col-md-6"><input type="text" name='name' id="name" value="<?php echo $this->input->post('Consume name');?>" class='form-control' placeholder='Consume Name' title='Consume Name' required autofocus /></div>   
            <div class="col-md-6"><input type="number" name='count' id='count' value="<?php echo $this->input->post('count');?>" class='form-control' placeholder='count' title='count' required /></div>         
          </div>
          <div class="form-group">            
            <div class="col-md-6"><input type="date" name='date' id='date' value="<?php echo $this->input->post('date');?>" class='form-control' placeholder='date' title='date' required /></div>
            <div class="col-md-6"><input type="number" name='doctor_id' id='doctor_id' value="<?php echo $this->input->post('doctor_id');?>" class='form-control' placeholder='doctor_id' title='doctor_id' required /></div>
          </div>
           <div class="form-group">                        
            <div class="col-md-6"><input type="number" name='price' id='price' value="<?php echo $this->input->post('price');?>" class='form-control' placeholder='price' title='price' required /></div>
          </div>
          <div class="clearfix"></div>
      </fieldset>
      <div class="form-group">
        <div class="col-md-6"><input type="submit" name='submit' id='submit' value='Register' class="form-control btn btn-info" /></div>
        <div class="col-md-6"><?php echo anchor('drug','Cancel',array('class'=>'form-control btn btn-info'));?></div>
      </div>
    <?php echo form_close(); ?>
  </div>
</div>
<script>
  $(document).ready(function(){

  });
</script>