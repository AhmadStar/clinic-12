<div class="panel panel-default">
  <div class="panel-heading">
    <h4 class="panel-title">
      <a href="#collapseDoctor" data-parent="#accordion" data-toggle="collapse">
        <span class="glyphicon glyphicon-file"></span> 
        Docotor
      </a>
    </h4>
  </div>
  <div class="panel-collapse collapse" id="collapseDoctor">
    <div class="panel-body">
      <table class="table">
        <tbody>
          <tr>
            <td>
              <span class="glyphicon glyphicon-file text-primary"></span><?php echo anchor('doctor',' Doctor List');?>
            </td>
          </tr>
          <tr>
            <td>
              <span class="glyphicon glyphicon-file text-primary"></span><?php echo anchor('doctor/new_doctor',' New Doctor');?>
            </td>
          </tr>                   
        </tbody>
      </table>
    </div>
  </div>
</div>