<div class="jumbtron">
  <h1 class="text-center well"><?php echo $title;?></h1>
</div>
