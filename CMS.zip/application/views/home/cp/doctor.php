<?php
  echo anchor('patient/','<span class="glyphicon glyphicon-user"></span> <br/>Patients',array("class"=>"btn btn-info btn-lg", "role"=>"button"));
  echo anchor('patient/waiting','<span class="glyphicon glyphicon-user"></span> <br/>Waiting List',array("class"=>"btn btn-info btn-lg", "role"=>"button"));
?>
