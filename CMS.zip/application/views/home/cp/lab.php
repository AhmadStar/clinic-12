<?php
  echo anchor('test/','<span class="glyphicon glyphicon-user"></span> <br/>Laboratory',array("class"=>"btn btn-danger btn-lg", "role"=>"button", "title"=>"List of All Tests"));
  echo anchor('test/new_test','<span class="glyphicon glyphicon-user"></span> <br/>Register New Test',array("class"=>"btn btn-danger btn-lg", "role"=>"button", "title"=>"Register New Test to Database"));
?>
